<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">  
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="keywords" content="Reconsder team"/>
	<meta name="description" content="Reconsder Team"/>
	<title>::Re-consider::Team</title>
	<link rel="shortcut icon" href="img/icon.png"/>
	<link rel="stylesheet" href="style/team.css" type="text/css" media="screen" charset="utf-8"/>
	<script type="text/javascript"  src="scripts/jquery-1.3.2.min.js"></script>
	<script type="text/javascript" src="scripts/basic.js"></script>
</head>
<body>
<div id="wrapper">

<div id="head1">
<div id="logo"><a href="index.php"><img src="img/logo.png"/></a></div>
<div id="banner">
<div id="search">Search <div><input type="text" placeholder="SEARCH" /></div> </div>
<div id="title"><!--<img src="img/title.png"/>-->"The Leap Of Faith" </div>
<div id="social">
<a href="https://www.facebook.com/helpinghand07"><img src="img/fb.gif"/></a><a href="http://www.twitter.org"><img src="img/twit.gif"/></a><a href="http://plus.google.com"><img src="img/gplus.gif"/></a>
</br>
<a href="#"><img src="img/share.gif"/></a>
</div>
</div>
</div>

<div class="cont">
<div class="mem"><h5>Anurag</h5>
<h6>Designation-Managing Director and Chairman </h6>

<p>He is the bhai (Brother) for everybody he knows. He is a person with lot of enthusiasm and zeal to help the society. 
As a student of Masters of Technology in SASTRA University, His dictionary doesn't have words like defeat,sad and various words which he is unattached with.
His aura is great and makes you feel his optimism.Immense Fun loving person and fun giving. His mantra of life is "Failure is fuel for your vehicle(LIFE)&quot;</p>
<img src="img/anurag.jpg" alt="anurag"/>
</div>
<div class="mem">
<h5>Anudeep</h5>
   <h6>Designation-Director</h6>

<p>He is known as a person with immense sincerity , feelings and boldness to defeat the defeat. Anna anudeep got his name Anna (Big Brother) from his friends for his immense kindness and zeal for sharing his life . 
Presently Pursuing his PHD in IIT-kanpur gave the most important insights and secret of living life happily and fully. His mantra of life is "Live Love Laugh"</p>
<img src="img/anudeep.jpg" alt="anudeep"/>
</div>
<div class="mem">
<h5>Anandini Valluri</h5> <h6>Designation-Chief Marketing Officer</h6>
Author of Book Celebrating Life

<p>Anandini Valluri is the author of the book celebrating Life. She is a person with an attitude to give back the society her wacky and crazy ideas for more liberated and
 happy existence. Her zest for life lies in her favorite motto&quot; The Universe wants you to be happy! So why not give it a chance!&quot;</p>
<img src="img/anandini.jpg" alt="anadini"/>
</div>
<div class="mem">
<h5>Siddhartha</h5><h6>Designation-Web Developer(Frontend)</h6>
<p>Siddhartha is in a long and complex relationship with technology. He just loves anything tech savvy to keep him occupied all day. While he is not seen tapping on his laptop, he has probably taken a break to read something interesting or he is playing 
his favourite sport. He studies Electrical engineering at SASTRA University, and he takes a lot of pride in his engineering skills. </p>
<img src="img/sid.jpg" alt="Sid"/>
</div>
<div class="mem">
<h5>Vikas Mishra </h5><h6> Designation-  Web Developer(Backend)</h6>


<p>Belief is a word which you have to believe. Vikas astonishes everyone with his dedication for work and sincerity. Words like hard work, determination, persistence are the words which describe him as a person. As a civil Engineer from SASTRA University. 
He has grown with his zeal to achieve great heights in his interest and domain. His mantra for life is &quot;Open your life & work for your desires&quot;</p>
<img src="img/vikas.jpg" alt="vikas"/>
</div>
<div class="mem">
 <h5>Ratna Devi</h5><h6> Designation-Creative Adviser</h6>
<p>
As a girl hailing from MUMBAI , everybody can expect her to be creative and adamant on precision of things. She has given immense inputs on small small things very precisely . 
Her Mantra for Life is "Hard work beats talent when talent doesn't work hard" </p>
<img src="img/ratna.jpg" alt="ratna"/>
</div>
</div>

<div id="footer">
<ul>
<li><a href="terms_policy.php">Privacy Policy</a></li>
<li><a href="terms_policy.php">Terms and Conditions</a></li>
<li><a href="team.php">Meet Our TEAM</a></li>
</ul>
<p>&copy2014 All Rights Reserved.  Re-consider is a group under "Prayukti Solutions Private Ltd"  incorporated under the Companies act of 1956. Registrar of Companies Andhra Pradesh Hyderabad</p>
</div>
</div>
</body>
</html>